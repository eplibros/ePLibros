#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from interfaz.W_main import Principal, Intercambio


def run():
    # Poner la ruta del fichero csv.zip
    libros = os.getcwd()
    Intercambio.libros = libros

    if os.path.isfile(os.path.join(libros, 'ePLibrosDescargar.py')):
    	os.unlink(os.path.join(libros, 'ePLibrosDescargar.py'))

    version = '1.2'
    mi_app = Principal(libros, version)
    Intercambio.app = mi_app
    mi_app.mostrar()

    return 0


# Para cuando funciona fuera de Sigil
if __name__ == "__main__":

    run()
