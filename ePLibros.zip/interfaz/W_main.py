#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import os
import codecs
import subprocess
from .widgets import *

try:
    import urllib.request as url
except:
    import urllib as url


imgdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'img')

#Fuentes
f = {'font_1': ('Verdana', 9, 50, False, False),
     'font_2': ('Verdana', 10, 75, False, True),
     'font_3': ('Trebuchet MS', 10, 50, False, False),
     'font_4': ('Arial', 9, 100, True, False),
     'font_5': ('Arial', 9, 50, False, False)
     }

#Colores
c = {'blanco': '#FFFFFF',
     'negro': '#000000',
     'azul': '#0000FF',
     'rojo': '#FF0000',
     'rojo_corrige': '#F4DFDF',
     'amarillo': '#FFFF00',
     'amarillo_corrige': '#F4F4DD',
     'verde_corrige': '#DFF4DF',
     'azul_update': '#abffea',
     'gainsboro': '#DCDCDC',
     'boton_gris': '#DEDEDE',
     'boton_azul': '#E0FFE7',
     'boton_update': '#abffea',
     'boton_config': '#82ff9e',
     'boton_crema': '#FFFF7F',
     'check_rojo': '#FF491C',
     'check_naranja': '#FFAE1C',
     'check_verde': '#82ff9e',
     'check_gris': '#AAAAAA',
     'cabecera_meta': '#CEFF49',
     'aviso': '#FFFF00',
     'error': '#FF0000',
     'gris': '#DCDCDC',
     'ok': '#FFFFFF'}


generos_ficcion = ['guion', 'novela', 'poesia', 'publicaciones periodicas', 'relato', 'teatro']

subgeneros_ficcion = ['aventuras', 'belico', 'ciencia ficcion', 'didactico', 'drama', 'erotico', 'fantastico', 'filosofico',\
                      'historico', 'humor', 'infantil', 'interactivo', 'intriga', 'juvenil', 'policial', 'psicologico', 'realista',\
                      'romantico', 'satira', 'terror', 'otros']

generos_noficcion = ['cronica', 'divulgacion', 'ensayo', 'publicaciones periodicas', 'referencia']

subgeneros_noficcion = ['arte', 'autoayuda', 'ciencias exactas', 'ciencias naturales', 'ciencias sociales', 'comunicacion',\
                        'critica y teoria literaria', 'deportes y juegos', 'diccionarios y enciclopedias', 'espiritualidad',\
                        'filosofia', 'historia', 'hogar', 'humor', 'idiomas', 'manuales y cursos', 'memorias', 'padres e hijos',\
                        'psicologia', 'salud y bienestar', 'sexualidad', 'tecnologia', 'viajes', 'otros']


iswindows = sys.platform.startswith('win')
isosx = sys.platform.startswith('darwin')
iscygwin = sys.platform.startswith('cygwin')
islinux = not (iswindows or isosx or iscygwin)


######################################################################################
# La clase Principal crea la ventana de la aplicación y todos sus componentes.
# Se usan los widgets personalizados para que no dependa del lenguaje usado (tk/qt).
######################################################################################
class Principal(Aplicacion):
    '''| Ventana principal de ePLMulti: aquí están los botones y se recoge los informes.
    '''
    def __init__(self, libros, version):
        try:
            Aplicacion.__init__(self, '902x440', 'ePLibros v' + version, os.path.join(imgdir, 'eplibros.gif'))
        except:
            Aplicacion.__init__(self, '902x440', 'ePLibros v' + version, os.path.join(imgdir, 'eplibros.png'))

        if os.path.isfile(os.path.join(libros, 'portada')):
            os.remove(os.path.join(libros, 'portada'))
        self.libros = libros
        self.pantallaInicial()
        Intercambio.app = self
        Intercambio.raiz = self.raiz
        self.avisoActualizacion(version)

    def inicio(self):
        self.fInicio = Cuadro(self.raiz, side='right', fill='both', expand='yes', borderwidth=2, relieve='groove', padx=0, pady=0)
        try:
            Etiqueta1(self.fInicio, image=os.path.join(imgdir, 'Biblio.png'), side='right', expand='yes', fill='both')
        except:
            Etiqueta1(self.fInicio, image=os.path.join(imgdir, 'Biblio.gif'), side='right', expand='yes', fill='both')
        self.fVentana = self.fInicio

    def gris(self):
        self.fGris = Cuadro(self.raiz, side='right', fill='both', expand='yes', borderwidth=2, relieve='groove', padx=0, pady=0)
        self.label_titi = Etiqueta1(self.fGris, text='Calculando...', side='right', expand='yes', fill='both', bg=c['blanco'], fg=c['negro'], fuente=f['font_1'])
        self.fVentana = self.fGris

    def blanca(self):
        self.fBlanca = Cuadro(self.raiz, side='right', fill='both', expand='yes', borderwidth=2, relieve='groove', padx=0, pady=0)
        self.tinfo = Texto(self.fBlanca,  relief='sunken', side='right', expand='yes', fill='both', scroll=True,  bg=c['blanco'], fg=c['negro'], fuente=f['font_3'])
        self.fVentana = self.fBlanca

    def entradasFilter(self):
        # Entrys
        e_padx = 8
        e_pady = 3
        b_padx = 8
        b_pady = 3
        self.fEntradas = Cuadro(self.raiz, side='left', fill='y', salto=True, borderwidth= 2, relieve='groove', padx=0, pady=0)
        self.lTitulo = Etiqueta1(self.fEntradas, text='Título', height= 15, side='top', expand='yes', fill='both', alineatexto='nw')
        self.eTitulo = Linea(self.fEntradas, raiz=self, width=250, height=20, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=e_padx, pady=e_pady) 
        self.lAutor = Etiqueta1(self.fEntradas, text='Autor', height= 15, side='top', expand='yes', fill='both', alineatexto='nw')
        self.eAutor = Linea(self.fEntradas, raiz=self, width=250, height=20, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=e_padx, pady=e_pady) 
        self.lColeccion = Etiqueta1(self.fEntradas, text='Colección', height= 15, side='top', expand='yes', fill='both', alineatexto='nw')
        self.eColeccion = Linea(self.fEntradas, raiz=self, width=250, height=20, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=e_padx, pady=e_pady) 
        self.lGeneros = Etiqueta1(self.fEntradas, text='Género', height= 15, side='top', expand='yes', fill='both', alineatexto='nw')
        self.eGeneros = Linea(self.fEntradas, raiz=self, width=250, height=20, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=e_padx, pady=e_pady) 
        self.lIdioma = Etiqueta1(self.fEntradas, text='Idioma', height= 15, side='top', expand='yes', fill='both', alineatexto='nw')
        self.eIdioma = Linea(self.fEntradas, raiz=self, width=250, height=20, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=e_padx, pady=e_pady) 
        self.lFechaI = Etiqueta1(self.fEntradas, text='Fecha inicial (dd-mm-aaaa)', height= 15, side='top', expand='yes', fill='both', alineatexto='nw')
        self.eFechaI = Linea(self.fEntradas, raiz=self, width=250, height=20, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=e_padx, pady=e_pady) 
        self.lFechaF = Etiqueta1(self.fEntradas, text='Fecha final (dd-mm-aaaa)', height= 15, side='top', expand='yes', fill='both', alineatexto='nw')
        self.eFechaF = Linea(self.fEntradas, raiz=self, width=250, height=20, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=e_padx, pady=e_pady) 
        self.bSalir = Boton(self.fEntradas, text='Salir del programa/Ver ayuda', width=250, height=25, command=self.termina, side='bottom', tip='Pulsa para cerrar la aplicación.', bg=c['boton_crema'], fg=c['negro'], estilo='2.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)
        self.bConfiguracion = Boton(self.fEntradas, text='Configurar/Actualizar ePLibros', relief='ridge', width=250, height=25, command=self.verConfig, side='bottom', tip='Configurar los datos a visualizar de cada libro.', bg=c['boton_update'], fg=c['negro'], estilo='3.TButton', fuente=f['font_5'], padx=b_padx, pady=b_pady)
        self.bVerLibros = Boton(self.fEntradas, text='Ver los libros que cumplen con el filtro', width=250, height=25, command=self.verLibros, side='bottom', tip='Pulsa para listar los libros que cumplen con el filtro.', bg=c['check_naranja'], fg=c['negro'], estilo='1.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)

        if isosx:
            self.bSalir.bind('<Button-2>', self.verAyuda)
        else:
            self.bSalir.bind('<Button-3>', self.verAyuda)

        if isosx:
            self.bConfiguracion.bind('<Button-2>', self.verUpdate)
        else:
            self.bConfiguracion.bind('<Button-3>', self.verUpdate)

    def configs(self):
        # labels
        c_padx = 18
        c_pady = 4
        self.fConfig1 = Cuadro(self.raiz, side='left', fill='y', salto=True, borderwidth=2, relieve='groove', padx=0, pady=8)
        self.eConfig = Linea(self.fConfig1, raiz=self, width=290, height=25, side='top', fill='both', expand='yes', borderwidth=2, relief='sunken', padx=c_padx, pady=c_pady) 
        self.lTitulo = Etiqueta2(self.fConfig1, text='1. Título', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el título del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lAutor = Etiqueta2(self.fConfig1, text='2. Autor', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el nombre del autor del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lGeneros = Etiqueta2(self.fConfig1, text='3. Géneros', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con los géneros del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lColeccion = Etiqueta2(self.fConfig1, text='4. Colección', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con la colección a la que pertenece el libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lVolumen = Etiqueta2(self.fConfig1, text='5. Volumen', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el número de volumen del libro, dentro de la colección.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lPublicacion = Etiqueta2(self.fConfig1, text='6. Fecha de publicación', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con la fecha de publicación del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        try:
            Etiqueta1(self.fConfig1, image=os.path.join(imgdir, 'libros.png'), side='bottom', expand='yes', fill='both')
        except:
            Etiqueta1(self.fConfig1, image=os.path.join(imgdir, 'libros.gif'), side='bottom', expand='yes', fill='both')
        self.fConfig2 = Cuadro(self.raiz, side='right', fill='y', salto=True, borderwidth=2, relieve='groove', padx=0, pady=8)
        self.lPaginas = Etiqueta2(self.fConfig2, text='7. Nº de páginas', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el número de páginas del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lRevision = Etiqueta2(self.fConfig2, text='8. Revisión', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el número de revisión del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lIdioma = Etiqueta2(self.fConfig2, text='9. Idioma', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el idioma del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lPublicado = Etiqueta2(self.fConfig2, text='10. Fecha publicación en la web', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con la fecha de publicación del libro, en la web.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lEstado = Etiqueta2(self.fConfig2, text='11. Estado', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el estado del libro.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lValoracion = Etiqueta2(self.fConfig2, text='12. Valoración en la web', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con la valoración del libro, en la web.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)
        self.lVotos = Etiqueta2(self.fConfig2, text='13. Nº de votos', width=290,  side='top', expand='yes', fill='both', fg=c['negro'], tip='Incluir una columna con el número de votos emitidos en la valoración del libro, en la web.', bg=c['check_verde'], fuente=f['font_4'], alineatexto='nw', padx=c_padx, pady=c_pady)

        try:
            Etiqueta1(self.fConfig2, image=os.path.join(imgdir, 'libros.png'), side='bottom', expand='yes', fill='both')
        except:
            Etiqueta1(self.fConfig2, image=os.path.join(imgdir, 'libros.gif'), side='bottom', expand='yes', fill='both')

        self.fConfig3 = Cuadro(self.raiz, side='right', fill='both', expand='yes', borderwidth=2, relieve='groove', padx=0, pady=0)
        self.eTitulo = Etiqueta1(self.fConfig3, width=310, height=30, text='Configuración de ePLibros', side='top', fuente=f['font_2'])
        try:
            Etiqueta1(self.fConfig3, image=os.path.join(imgdir, 'Titivillus.png'), side='top', expand='yes', fill='both')
        except:
            Etiqueta1(self.fConfig3, image=os.path.join(imgdir, 'Titivillus.gif'), side='top', expand='yes', fill='both')
        self.bGuardar = Boton(self.fConfig3, text='Guardar', width=160, height=25, command=self.cerrarConfig, side='bottom', tip='Guardar la configuración actual', bg=c['boton_crema'], fg=c['negro'], estilo='2.TButton', fuente=f['font_4'], padx=c_padx, pady=c_pady)

    def entradasListado(self):
        b_padx = 8
        b_pady = 3
        self.fListado = Cuadro(self.raiz, side='bottom', fill='x', salto=True, borderwidth= 2, relieve='groove', padx=0, pady=0)
        self.bSalir = Boton(self.fListado, text='Salir del programa', width=200, height=25, command=self.termina, side='left', tip='Pulsa para cerrar la aplicación.', bg=c['boton_crema'], fg=c['negro'], estilo='1.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)
        self.bVolver = Boton(self.fListado, text='Volver a pantalla inicial', width=200, height=25, command=self.volver, side='left', tip='Pulsa para volver a la pantalla inicial de la aplicación.', bg=c['rojo_corrige'], fg=c['negro'], estilo='2.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)
        self.bDescargar = Boton(self.fListado, text='Descargar magnets', relief='ridge', width=200, height=25, command=self.descargarMagnet, side='left', tip='Pulsa para descargar los magnet de los libros seleccionados.', bg=c['boton_update'], fg=c['negro'], estilo='3.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)
        self.bCopiar = Boton(self.fListado, text='Copiar magnets', relief='ridge', width=200, height=25, command=self.copiarMagnet, side='left', tip='Pulsa para copiar los magnet de los libros seleccionados.', bg=c['check_verde'], fg=c['negro'], estilo='4.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)
        self.bDatos = Boton(self.fListado, text='Información libros', relief='ridge', width=200, height=25, command=self.llamar_informeLibro, side='left', tip='Pulsa para obtener un informe completo de los libros seleccionados.', bg=c['check_naranja'], fg=c['negro'], estilo='5.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)
        self.bOrdenar = Boton(self.fListado, text='Ordenar columnas', relief='ridge', width=200, height=25, side='left', tip='Pulsa para ordenar según las columnas elegidas.', bg=c['check_rojo'], fg=c['negro'], estilo='6.TButton', fuente=f['font_4'], padx=b_padx, pady=b_pady)
        self.fFiltro = Cuadro(self.raiz, side='bottom', fill='x', salto=True, borderwidth= 2, relieve='groove', padx=0, pady=0)
        self.lLibros = Etiqueta1(self.fFiltro, height= 15, side='top', expand='yes', fill='both', alineatexto='center')

    #Lee la configuración en el fichero config.txt
    def leerConfig(self):
        if os.path.isfile(os.path.join(self.libros, 'config.txt')):
            Configuracion = open(os.path.join(self.libros, 'config.txt'), 'r')
        else:
            with open(os.path.join(self.libros, 'config.txt'), 'w') as Configuracion:
                Configuracion.write('1-2-3-4-5-9-10')
                Configuracion.close()
                Configuracion = open(os.path.join(self.libros, 'config.txt'), 'r')

        Intercambio.Configura = Configuracion.readline()

    # Lee la configuración y la guarda en el fichero 'config.txt'
    def salvarConfig(self):
        with open(os.path.join(self.libros, 'config.txt'), 'w') as Configuracion:
            Configuracion.write(self.eConfig.lee())
            Configuracion.close()

    def cerrarConfig(self):
        self.salvarConfig()
        self.fConfig1.destroy()
        self.fConfig2.destroy()
        self.fConfig3.destroy()
        self.pantallaInicial()

    def verConfig(self):
        '''| Configuración de los parámetros generales usados por ePLMulti.
        '''
        self.fVentana.destroy()
        self.fEntradas.destroy()
        self.configs()
        self.leerConfig()
        self.eConfig.inserta('end', Intercambio.Configura)

    def pantallaInicial(self):
        '''| Mostrar la ventana inicial de la aplicación
        '''
        self.entradasFilter()
        self.inicio()

    def ponGris(self):
        '''| Mostrar la ventana de notificaciones.
        '''
        self.fVentana.oculta()
        self.gris()

    def ponBlanca(self):
        '''| Mostrar la ventana de texto para informes.
        '''
        try:
            self.fVentana.oculta()
        except:
            pass
        self.blanca()

    def termina(self):
        '''#| Cierra ePLMulti.
        '''
        if os.path.isfile(os.path.join(self.libros, 'portada')):
            os.remove(os.path.join(self.libros, 'portada'))

        self.raiz.destroy()

    def verAyuda(self, event):
        ayuda = os.path.join(self.libros, 'ayuda', 'ayuda.xml')

        if Intercambio.ayuda_abierta:
            self.fVentana.destroy()
            self.inicio()

        try:
            if os.path.isfile(ayuda) and not Intercambio.ayuda_abierta:
                with codecs.open(ayuda, 'r', 'iso8859_15') as f:
                    ttexto = f.read()
                    ttexto = ttexto.replace('\r\n', '\n')
                    self.ponBlanca()
                    self.tinfo.borra()
                    self.tinfo.inserta('1.0', ttexto)
                    self.tinfo.desactiva()
                    Intercambio.ayuda_abierta = True
            else:
                Intercambio.ayuda_abierta = False
        except Exception as ex:
            print(ex)

    def verLibros(self):
        self.leerConfig()
        self.hilo_carga()

    def cargarCSV(self):
        from CSV.librosEPL import cargarLibros

        log('Leyendo el CSV. Espere un momento.', False)
        Intercambio.aportes = cargarLibros()

    def listarCSV(self):
        from CSV.librosEPL import verTabla, listarFiltrados

        self.insertados = dict()
        log('El programa está listando los libros que cumplen con el filtro.\nEsto puede llevar unos pocos segundos.', False)
        self.tree = verTabla(self.raiz)
        self.insertados = listarFiltrados(self.raiz, self.fVentana, self.fEntradas, Intercambio.aportes,\
                                          self.filtro, self.tree)
        self.tree.bind('<Double-Button-1>', self.llamar_informeLibro)

    def hilo_carga(self):
        if self.ponerFiltro():
            self.ponGris()
            if not Intercambio.volver:
                self.cargarCSV()
                Intercambio.volver = True
                if len(Intercambio.aportes) != 0:
                    self.listarCSV()
                else:
                    log('No existen aportes que listar.', False)
            elif Intercambio.volver:
                if len(Intercambio.aportes) != 0:
                    self.listarCSV()
                else:
                    log('No existen aportes que listar.', False)

    def depurarGeneros(self):
        from CSV.librosEPL import quitarAcentos

        if self.eGeneros.lee() == '':
            return True

        generos = (self.eGeneros.lee()).split(',')

        for gen in generos:
            gen = gen.lower()
            gen = quitarAcentos(gen) 
            if (gen in generos_ficcion) or (gen in generos_noficcion) or (gen in subgeneros_ficcion) or (gen in subgeneros_noficcion):
                return True
            else:
                mensajeBox('ePLibros', 'El filtro de generos no es correcto.', 'ok')
                self.eGeneros.borra(0, 'end')

    def depurarFiltro(self):
        #Comprobar que las fechas son homogéneas
        fechaIni = self.eFechaI.lee()
        fechaFin = self.eFechaF.lee()
        if fechaIni.find(':') == fechaFin.find(':') == -1:
            pass
        elif fechaIni == '' and fechaFin != '':
            pass
        elif fechaIni != '' and fechaFin == '':
            pass
        elif fechaIni.find('P:') == fechaFin.find('P:') == 0:
            pass
        elif fechaIni.find('A:') == fechaFin.find('A:') == 0:
            pass
        else:
            mensajeBox('ePLibros', 'Hay errores en las fechas del filtro', 'ok')
            self.eFechaI.borra(0, 'end')
            self.eFechaF.borra(0, 'end')
            return False

        return True

    def ponerFiltro(self):
        if self.depurarFiltro() and self.depurarGeneros() :
            self.filtro = []
            self.filtro.append(self.eTitulo.lee())
            self.filtro.append(self.eAutor.lee())
            self.filtro.append(self.eGeneros.lee())
            self.filtro.append(self.eColeccion.lee())
            self.filtro.append(self.eIdioma.lee())
            self.filtro.append(self.eFechaI.lee())
            self.filtro.append(self.eFechaF.lee())

            return True
        else:
            return False

    def volver(self):
        Intercambio.volver = True
        Intercambio.tv.destroy()
        self.fListado.destroy()
        self.fFiltro.destroy()
        self.pantallaInicial()
        if iswindows or isosx:
            try:
                self.raiz.state('normal')
            except:
                self.raiz.attributes('-fullscreen', False)
        elif islinux:
            self.raiz.attributes('-zoomed', False)

    def descargarMagnet(self):
        for idx in Intercambio.tv.selection():
            titulo = Intercambio.tv.item(idx)['values'][0]
            torrent = Intercambio.tv.item(idx)['values'][13]

            lista_torrents = []
            if not torrent.find(',') == -1:
                lista_torrents = torrent.split(',')
            else:
                lista_torrents.append(torrent)

            for torrent in lista_torrents:
                torrent = torrent.lstrip(' ')
                if type(titulo) != 'str':
                    titulo = str(titulo)
                titulo = '_'.join(titulo.split(' '))
                magnet = 'magnet:?xt=urn:btih:' + torrent + '&dn=EPL_[' + idx + ']_' + titulo

                if islinux:
                    subprocess.Popen(['xdg-open', magnet], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                elif iswindows or iscygwin:
                    os.startfile(magnet)
                elif isosx:
                    subprocess.Popen(['open', magnet], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                else:
                    subprocess.Popen(['xdg-open', magnet], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def copiarMagnet(self):
        self.raiz.clipboard_clear()
        magnet = ''
        for idx in Intercambio.tv.selection():
            titulo = Intercambio.tv.item(idx)['values'][0]
            torrent = Intercambio.tv.item(idx)['values'][13]

            lista_torrents = []
            if not torrent.find(',') == -1:
                lista_torrents = torrent.split(',')
            else:
                lista_torrents.append(torrent)

            for torrent in lista_torrents:
                torrent = torrent.lstrip(' ')
                if type(titulo) != 'str':
                    titulo = str(titulo)
                titulo = '_'.join(titulo.split(' '))
                magnet += 'magnet:?xt=urn:btih:' + torrent + '&dn=EPL_[' + idx + ']_' + titulo + '\n'

        self.raiz.clipboard_append(magnet)

    def llamar_informeLibro(self, evento=None):
        if evento:
            self.informeLibro(Intercambio.tv.selection()[0])
        else:
            for idx in Intercambio.tv.selection():
                self.informeLibro(idx)

    def informeLibro(self, idx):
        from CSV.librosEPL import limpiarFecha

        libro = []
        libro = self.insertados[idx]
        informe = dict()
        lista_informe = []
        informe['EPL_ID: '] = str(idx)
        informe['Título: '] = unicode_str(libro[1])
        informe['Autor: '] = unicode_str(libro[2])
        informe['Género: '] = unicode_str(libro[3])
        if not unicode_str(libro[4]) == '':
            informe['Colección: '] = unicode_str(libro[4])
        if not unicode_str(libro[5]) == '':
            informe['Volumen: '] = unicode_str(libro[5])
        informe['Fecha de publicación: '] = unicode_str(libro[6])
        informe['Sinopsis: '] = unicode_str(libro[7])
        informe['Nº de páginas: '] = unicode_str(libro[8])
        informe['Revisión: '] = unicode_str(libro[9])
        informe['Idioma: '] = unicode_str(libro[10])
        informe['Publicado en la web: '] = limpiarFecha(unicode_str(libro[11]))
        informe['Estado: '] = unicode_str(libro[12])
        if not unicode_str(libro[13]) == '':
            informe['Valoración: '] = unicode_str(libro[13])
        informe['Nº de votos: '] = unicode_str(libro[14])
        informe['Portada: '] = libro[16].replace('"', '')

        lista_informe = []
        lista_informe.append('Título: ')
        lista_informe.append('Autor: ')
        lista_informe.append('Género: ')
        if not unicode_str(libro[4]) == '':
            lista_informe.append('Colección: ')
        if not unicode_str(libro[5]) == '':
            lista_informe.append('Volumen: ')
        lista_informe.append('Fecha de publicación: ')
        lista_informe.append('Nº de páginas: ')
        lista_informe.append('Idioma: ')

        lista_informe.append('Sinopsis: ')

        lista_informe.append('EPL_ID: ')
        lista_informe.append('Revisión: ')
        lista_informe.append('Publicado en la web: ')
        lista_informe.append('Estado: ')
        if not unicode_str(libro[13]) == '':
            lista_informe.append('Valoración: ')
        lista_informe.append('Nº de votos: ')
        lista_informe.append('Portada: ')

        titulo = unicode_str(libro[1])
        portada = libro[16]
        if portada.find('imgur') != -1:
            portada = portada.replace(':', 's:')

        if portada.endswith('png"\n') or portada.endswith('gif"\n'):
            portada_JPG = False
        else:
            portada_JPG = True

        try:
            url.urlretrieve(portada, "portada")
            InformeLibro('Informe de: ' + titulo, os.path.join(imgdir, 'eplibros.png'), informe, lista_informe, self.raiz, "portada", portada_JPG)
        except:
            InformeLibro('Informe de: ' + titulo, os.path.join(imgdir, 'eplibros.png'), informe, lista_informe, self.raiz)

    def avisoActualizacion(self, version1):
        from urllib.request import urlopen

        url = 'http://libros.freevar.com/ePLibros/version.xml'
        resp = urlopen(url, timeout=10)

        if resp:
            version2 = resp.read()
            version2 = version2.decode('utf-8')
            Intercambio.version = version2
            try:
                if version1 < float(version2):
                    self.ponGris()
                    log('Existe una nueva versión lista para descargarse.\nPulse el botón de color verde de la pantalla\ncon el botón derecho del ratón.', False)
                    Intercambio.descargar = True
            except:
                self.ponGris()
                log('La conexión con el servidor de actualización no es correcta.\nNo es posible actualizarse a una nueva versión.\nPero es posible seguir normalmente con el programa.', False)
        else:
            self.ponGris()
            log('No ha sido posible establecer conexión\ncon el servidor de actualización.', False)

    def verUpdate(self, event):
        from .update import actualizar

        if Intercambio.descargar:
            log('El programa se está actualizando, espere un momento.', False)
            actualizar(self.libros, Intercambio.version)
            Intercambio.descargar = False


def log(texto, imprime=True):

    if imprime:
        old_stdout = sys.stdout
        sys.stdout = sys.__stdout__
        print(texto)
        sys.stdout = old_stdout
    else:
        Intercambio.app.label_titi.inserta(unicode_str(texto))
        Intercambio.app.label_titi.muestrasinesperar()


def unicode_str(p, enc='utf-8'):

    PY2 = sys.version_info[0] == 2
    if PY2:
        text_type = unicode
    else:
        text_type = str

    if p is None:
        return None
    if isinstance(p, text_type):
        return p
    try:
        return p.decode(enc)
    except:
        return p.decode('cp1252')


def handle_exception(exc_type, exc_value, exc_traceback):
    import traceback

    Intercambio.app.destruirWidgets()
    Intercambio.app.ponBlanca()
    Intercambio.app.tinfo.inserta('1.0', ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback)))


class Intercambio(object):

    app = None
    libros = ''
    Configura = dict()
    lista_ordenar = []
    lista_tuplas_insertadas = []
    raiz = None
    tv = None
    aportes = []
    volver = False
    ayuda_abierta = False
    version = ''
    descargar = False
