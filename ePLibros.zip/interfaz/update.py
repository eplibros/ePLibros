#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import zipfile
import shutil
from io import BytesIO
from urllib.request import urlopen
from .W_main import log

url = 'http://libros.freevar.com/ePLibros/ePLibros.zip'


def actualizar(libros, version):
    try:
        resp = urlopen(url)
        myzipfile = zipfile.ZipFile(BytesIO(resp.read()))

        folder = libros
        ruta_csv = os.path.join(libros, 'csv_full_imgs.csv')
        ruta_datos = os.path.join(libros, 'datos_csv.txt')
        ruta_config = os.path.join(libros, 'config.txt')
        for the_file in os.listdir(folder):
            file_path = os.path.join(folder, the_file)
            try:
                if os.path.isfile(file_path) and not file_path == ruta_csv and not file_path == ruta_datos and not file_path == ruta_config:
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print(e)

        myzipfile.extractall()
        log('El programa se ha actualizado a la versión ' + version, False)
    except:
        log('El programa no se ha podido actualizar.', False)