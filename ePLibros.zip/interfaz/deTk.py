#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals

import sys
from .W_tip import createToolTip

import tkinter as tk
import tkinter.ttk as ttk
import tkinter.font as tkFont
from tkinter import Tk, Frame, LabelFrame, Label, PhotoImage, StringVar, Text, Scrollbar, Toplevel, Entry, messagebox
from tkinter.messagebox import askyesno


iswindows = sys.platform.startswith('win')
isosx = sys.platform.startswith('darwin')
islinux = not (iswindows or isosx)

######################################################################################
# Desde este fichero habría que hacer cualquier llamada a las librerías de tkinter
# y luego desde aquí se cargaría a widgets.py y de allí a cualquier punto de la aplicación.
# Muy importante es que cada clase, cada método, tenga su equivalente en deQt.py
# así widgets.py tendrá siempre la misma estructura independientemente de la librería
# que se haya cargado.
######################################################################################

indice = 1000
#s = ttk.Style()
#s.theme_use('default')

######################################################################################
# La clase Aplicación representa la ventana principal de la aplicación y no debería
# usarse para, por ejemplo, ventanas emergentes.
# Aquí ponemos las operaciones básicas como la geometría y demás que tengan un lenguaje
# propio de esta librería.
######################################################################################
class Aplicacion(object):
    ''' Ventana principal de ePLMulti: aquí están los botones y se recoge los informes.
    '''

    def __init__(self, dimensiones, titulo, icono):
        from .W_main import Intercambio, handle_exception

        self.raiz = Tk()
        self.dimensiones = dimensiones
        self.raiz.geometry(self.dimensiones)

        #Para capturar las excepciones de los módulos, sólo sirve si se ejecuta desde Sigil
        self.raiz.report_callback_exception = handle_exception

        self.raiz.protocol("WM_DELETE_WINDOW", self.termina)

        self.raiz.resizable(width=True, height=True)
        self.raiz.title(titulo)
        icono = PhotoImage(file=icono)
        self.raiz.call('wm', 'iconphoto', self.raiz._w, icono)

        self.raiz.config(padx=10, pady=10)

        if islinux:
            # Para que los mensajes askyesno se muestren
            # con una letra correcta en linux
            self.raiz.option_add('*font', 'Tahoma 9')

    def titulo(self, texto):
        self.raiz.title(texto)

    def mostrar(self):
        ''' Muestra la ventana de la aplicación.
        '''
        [width, height] = map(int, self.dimensiones.split('x'))
        ws = self.raiz.winfo_screenwidth()
        hs = self.raiz.winfo_screenheight()
        x = (ws / 2) - (width / 2)
        y = (hs / 2) - (height / 2)
        self.raiz.geometry('+%d+%d' % (x, y))

        self.raiz.mainloop()

    def cierra(self):
        ''' Cierra la aplicación.
        '''
        self.raiz.destroy()

    def destruirWidgets(self):
        lista = self.raiz.pack_slaves()
        for widget in lista:
            widget.destroy()


######################################################################################
# La clase Comun recoge una serie de métodos comunes a todos los widgets, para ahorrar
# código. Lógicamente, la lista en tkinter es más larga, pero sólo he puesto los que
# son necesarios por ahora. Se pueden ir añadiendo a medida que se necesiten.
######################################################################################
class Comun(object):
    ''' Métodos comunes a los widgets.
    '''

    def muestra(self, side=None, expand=None, fill=None, sinmargen=None, padx=None, pady=None, anchor=None):
        ''' Una vez definido el widget, lo mostramos con este método en la aplicación.
        '''
        if side or expand or fill:
            self.pack(side=side, expand=expand, fill=fill, padx=padx, pady=pady, anchor=anchor)

    def recarga(self, side=None, expand=None, fill=None, padx=None, pady=None):
        ''' Mostrar los cambios en un widget.
        '''
        self.pack(side=side, expand=expand, fill=fill, padx=padx, pady=pady)
        self.marco.update_idletasks()

    def oculta(self):
        ''' Oculta el widget.
        '''
        self.pack_forget()

    def desoculta(self):
        ''' Desoculta el widget.
        '''
        self.pack()

    def activa(self):
        '''Activa el widget para pueda pulsarse.
        '''
        self.config(state=tk.ENABLED)

    def desactiva(self):
        '''Desactiva el widget para que no pueda pulsarse.
        '''
        self.config(state=tk.DISABLED)

    def muestrasinesperar(self):
        ''' Muestra el widget sin esperar a regenerar la ventana completa.
        '''
        self.update_idletasks()

    def pontip(self, tip):
        ''' Coloca un nuevo tip en el widget.
        '''
        createToolTip(self, tip)

    def ponbg(self, bg):
        ''' Coloca el color de fondo en el widget.
        '''
        self.configure(bg=bg)

    def ponfg(self, fg):
        ''' Coloca el color del texto en el widget.
        '''
        self.configure(fg=fg)
        self.configure(disabledforeground=fg)

    def ancho(self):
        ''' Devuelve el ancho del widget.
        '''
        return self.winfo_width()

    def alto(self):
        ''' Devuelve el alto del widget.
        '''
        return self.winfo_height()

    def setfocus(self):
        ''' Colocar el focus en el widget.
        '''
        return self.focus_set()

    def cierra(self):
        ''' Elimina el widget.
        '''
        self.destroy()

    def _aspecto(self, width=None, height=None, bg=None, fg=None, fuente=None, tip=None, relief=None, borderwidth=None, padx=None, pady=None):
        ''' Modificación del aspecto del widge en base a los parámetros indicados
        '''
        ###################################################################
        # Pendiente de comprobar
        if tip: createToolTip(self, tip)
        if width: self.configure(width=width)
        if height: self.configure(height=height)
        if padx: self.configure(padx=padx)
        if pady: self.configure(pady=pady)
        if bg: self.configure(bg=bg)
        #if fg: self.configure(bg=fg)
        if fg: self.configure(fg=fg)
        if fuente:
            f1 = fuente[0]
            f2 = fuente[1]
            f3 = fuente[2]
            f4 = fuente[3]
            f5 = fuente[4]
            if f3 > 74:
                f3 = 'bold'
            else:
                f3 = 'normal'
            if f4:
                f4 = 'italic'
            else:
                f4 = 'roman'
            if f5:
                f5 = 1
            else:
                f5 = 0
            fuente = tkFont.Font(family=f1, size=f2, weight=f3, slant=f4, underline=f5)
            self.font = fuente
            self.config(font=self.font)
        if relief:
            if relief == 'flat':
                self.config(relief=tk.FLAT)
            elif relief == 'raised':
                self.config(relief=tk.RAISED)
            elif relief == 'sunken':
                self.config(relief=tk.SUNKEN)
            elif relief == 'groove':
                self.config(relief=tk.GROOVE)
            elif relief == 'ridge':
                self.config(relief=tk.RIDGE)
        if borderwidth: self.config(bd=borderwidth)


######################################################################################
# La clase Cuadro recoge todo el contenido de las clases Frame de tkinter y Comun
# Para ahorrar código, se incluyen aquí las tareas de mostrar el widget.
######################################################################################
class Cuadro(LabelFrame, Comun):
    ''' Crea un cuadro donde colocar los widgets.
    '''

    def __init__(self, marco, side=None, expand=None, fill=None, width=None, salto=False, borderwidth=0, relieve=None, flat=None, titulo=None, padx=None, pady=None, sinmargen=None, espaciamiento=None):
        padx, pady = padx_pady(padx, pady, sinmargen)
        LabelFrame.__init__(self, marco, borderwidth=borderwidth, relief=relieve, padx=padx, pady=pady)
        if flat:
            self.configure(relief=tk.FLAT, borderwidth=0)
        if titulo:
            self.config(text=titulo)

        self.muestra(side=side, expand=expand, fill=fill)


######################################################################################
# La clase Etiqueta recoge todo el contenido de las clases Label de tkinter y Comun
# Para ahorrar código, se incluyen aquí las tareas de mostrar el widget.
# Hay que tener en cuenta que si se especifica una imagen, se representará la imagen
# ignorándose cualquier texto que se haya especificado.
######################################################################################
class Etiqueta1(Label, Comun):
    ''' Crea una etiqueta que puede representar texto o imágenes.
    '''

    def __init__(self, marco, text=None, image=None, width=None, height=None, side=None, expand=None, fill=None, tip=None, bg=None, fg=None, fuente=None, alineatexto=None, padx=None, pady=None, sinmargen=None):
        if image:
            from PIL import Image, ImageTk

            self.img = Image.open(image)
            try:
                self.resized = self.img.resize((int(width*.95), int(height*.95)), Image.ANTIALIAS)
                self.background_image = ImageTk.PhotoImage(self.resized)
            except:
                self.background_image = ImageTk.PhotoImage(self.img)
            Label.__init__(self, marco, image=self.background_image, anchor=alineatexto)
        else:
            padx, pady = padx_pady(padx, pady)
            if width == None:
                width = 0
            if height == None:
                height = 0
            frame = Frame(marco, width=width + 2 * padx, height=height + 2 * pady, padx=padx, pady=pady)
            frame.pack_propagate(0)
            frame.pack(side=side, expand=expand, fill=fill)

            Label.__init__(self, frame, text=text)
            if alineatexto:
                self.config(anchor=alineatexto)
            v = tk.StringVar()
            self.config(textvariable=v)
            self.val = v
            self.val.set(text)

        self._aspecto(width=width, height=height, bg=bg, fg=fg, fuente=fuente, tip=tip)
        self.muestra(side=side,  fill=fill, expand=expand)

    def inserta(self, text=None, bg=None):
        ''' Método para insertar texto en la etiqueta, asignándole un color si se desea.
        No se comprueba que sea una etiqueta con texto y no con imágenes. Supongo que en caso de tener una
        imagen, se sustiturá por el texto.
        '''
        self.val.set(text)
        if bg:
            self.configure(bg=bg)
        self.muestrasinesperar()

    def lee(self):
        ''' Devuelve el valor de la etiqueta.
        '''
        return self.val.get()


class Etiquetattk(ttk.Label):

    def __init__(self, *args, **kwargs):
        ttk.Label.__init__(self, *args, **kwargs)


######################################################################################
# La clase Etiqueta recoge todo el contenido de las clases Label de tkinter y Comun
# Para ahorrar código, se incluyen aquí las tareas de mostrar el widget.
# Hay que tener en cuenta que si se especifica una imagen, se representará la imagen
# ignorándose cualquier texto que se haya especificado.
######################################################################################
class Etiqueta2(Etiquetattk, Comun):
    ''' Crea una etiqueta que puede representar texto o imágenes.
    '''

    def __init__(self, marco, text=None, image=None, width=None, height=None, side=None, expand=None, fill=None, tip=None, bg=None, fg=None, fuente=None, alineatexto=None, justify= None, padx=None, pady=None, sinmargen=None):
        if image:
            from PIL import ImageTk

            self.img = ImageTk.PhotoImage(file=image)
            Etiquetattk.__init__(self, marco, image=self.img)

            if bg:
                self.configure(background=bg)
            if alineatexto:
                self.config(anchor=alineatexto)
        else:
            padx, pady = padx_pady(padx, pady)
            if width == None:
                width = 0
            if height == None:
                height = 0
            frame = Frame(marco, width=width + 2 * padx, height=height + 2 * pady, padx=padx, pady=pady)
            frame.pack_propagate(0)
            frame.pack(side=side, expand=expand, fill=fill)

            Etiquetattk.__init__(self, frame, text=text)
            if bg:
                self.configure(background=bg)
            if fg:
                self.configure(foreground=fg)
            if alineatexto:
                self.config(anchor=alineatexto)
            if justify:
                self.config(justify=justify)
            v = tk.StringVar()
            self.config(textvariable=v)
            self.val = v
            self.val.set(text)

        self._aspecto(width=width, fuente=fuente, tip=tip)
        self.muestra(side=side,  fill=fill, expand=expand)

    def inserta(self, text=None, bg=None):
        ''' Método para insertar texto en la etiqueta, asignándole un color si se desea.
        No se comprueba que sea una etiqueta con texto y no con imágenes. Supongo que en caso de tener una
        imagen, se sustiturá por el texto.
        '''
        self.val.set(text)
        if bg:
            self.configure(background=bg)
        self.muestrasinesperar()

    def lee(self):
        ''' Devuelve el valor de la etiqueta.
        '''
        return self.val.get()


######################################################################################
# La clase Texto recoge todo el contenido de las clases Text de tkinter y Comun
# Para ahorrar código, se incluyen aquí las tareas de colocar una barra de scroll y
# mostrar el widget.
# Ha de tenerse en cuenta que este widget está indicado para editar el texto en oposición
# a Etiqueta que sólo lo muestra.
######################################################################################
class Texto(Text, Comun):
    ''' Crea un cuadro donde colocar los textos o informes.
    '''

    def __init__(self, marco, width=None, height=None, relief=None, side=None, expand=None, fill=None, onModify=None, scroll=None, bg=None, fg=None, fuente=None, borderwidth=None, padx=None, pady=None, sinmargen=None):
        self.marco = marco
        padx, pady = padx_pady(padx, pady, sinmargen)
        if width == None:
            width = 0
        if height == None:
            height = 0
        frame = Frame(marco, width=width + 2 * padx, height=height + 2 * pady, padx=padx, pady=pady)
        frame.pack_propagate(0)
        frame.pack(side=side, expand=expand, fill=fill)

        Text.__init__(self, frame, relief=relief)

        if scroll:
            self.ybar = Scrollbar(frame)                   ############################################
            self.ybar.config(command=self.yview)                # Se podría poner con listas los parámetros
            self.config(yscrollcommand=self.ybar.set)           # variables, pero de momento es mejor así
            self.ybar.pack(side='right', fill='y')              # para tenerlos controlados

        self.configure(wrap=tk.WORD)

        self._aspecto(width=width, height=height, bg=bg, fg=fg, fuente=fuente, relief=relief, borderwidth=borderwidth)
        self.muestra(side=side,  fill=fill, expand=expand)

    def inserta(self, posicion, texto, color=None, comando=None, ind=None, tag=None):
        ''' Insertar texto dentro del widget en la posición indicada.
        '''
        if color or comando:
            global indice
            indice += 1
            tag = 'link' + str(indice)
            ###################################################################
            # El uso de tag parece que impide seleccionar texto en el informe
            # queda pendiente investigar cómo hacerlo.
            ###################################################################
            self.insert(posicion, texto, tag)
            if color:
                if Sigilbk.erratas:
                    self.tag_config(tag, background=color)
                else:
                    self.tag_config(tag, foreground=color)
            if comando:
                self.tag_bind(tag, '<Button-1>', comando)
        elif tag:
            self.insert(posicion, texto, tag)
        else:
            self.insert(posicion, texto)

    def lee(self):
        ''' Devuelve el contenido del Texto en forma de texto plano.
        '''
        return self.get("1.0", 'end')

    def movercursor(self):
        ''' Por compatibilidad con PyQt
        '''
        pass

    def borra(self):
        ''' Borra el contenido.
        '''
        self.delete("1.0", 'end')


######################################################################################
# La claseLinea recoge todo el contenido de las clases Entry de T/tkinter y Comun
# Para ahorrar código, se incluye aquí la tarea de mostrar el widget.
# Ha de tenerse en cuenta que este widget está indicado para editar el texto en oposición
# a Etiqueta que sólo lo muestra.
######################################################################################
class Linea(Entry, Comun):
    ''' Crea un cuadro donde colocar los textos o informes.
    '''

    def __init__(self, marco, raiz=None, width=None, height=None, side=None, expand=None, fill=None, scroll=None, bg=None, fg=None, fuente=None, relief=None, borderwidth=None, padx=None, pady=None, sinmargen=None, validatecommand=None):
        padx, pady = padx_pady(padx, pady, sinmargen)
        self.frame = Frame(marco, width=width + 2 * padx, height=height + 2 * pady, padx=padx, pady=pady)
        self.frame.pack_propagate(0)
        self.frame.pack(side=side)

        Entry.__init__(self, self.frame)

        v = tk.StringVar()
        self.config(textvariable=v)
        self.val = v

        self._aspecto(bg=bg, fg=fg, fuente=fuente, relief=relief, borderwidth=borderwidth)
        self.muestra(side=side, expand=expand, fill=fill)

    def inserta(self, posicion, texto):
        ''' Insertar texto dentro del widget en la posición indicada.
        '''
        if posicion == 'end':
            self.val.set(texto)

    def lee(self):
        ''' Devuelve el contenido del Texto en forma de texto plano.
        '''
        return self.val.get()

    def borra(self, inicio, final=None):
        ''' Borra el contenido.
        '''
        if final:
            self.delete(inicio, final)
        else:
            self.delete(inicio)


class Emergente(Toplevel):
    ''' Crea una ventana del tipo toplevel, es decir, una ventana secundaria donde se presenta un diálogo.
    '''

    def __init__(self, marco, dimensiones, titulo, icono):
        from .W_main import Intercambio

        self.marco = marco
        Toplevel.__init__(self, self.marco)
        if self.marco is None:
            pos_ventana = '50+50'
            self.geometry(dimensiones + '+' + pos_ventana)
        else:
            [width, height] = map(int, dimensiones.split('x'))
            ws = marco.winfo_screenwidth()
            hs = marco.winfo_screenheight()
            x = (ws / 2) - (width / 2)
            y = (hs / 2) - (height / 2)
            self.geometry('+%d+%d' % (x, y))
        self.transient(self.marco)
        if not islinux:
            self.grab_set()
        self.focus_set()
        self.resizable(width=True, height=True)
        self.title(titulo)
        icono = PhotoImage(file=icono)
        self.tk.call('wm', 'iconphoto', self._w, icono)

        self.protocol("WM_DELETE_WINDOW", self.terminar)

    def espera(self):
        ''' La ventana principal esperará a que termine la emergente para continuar y procesar los datos.
        '''
        self.marco.wait_window(self)

    def cerrar(self):
        ''' Método temporal creado para poder ejecutar la ventana secundaria dentro del ePLMulti
        basado en tkinter y por compatibilidad con la versión qt.
        Desde el momento en que todo vaya en qt esto sobrará.
        '''
        #######################################################################
        # Esto hay que normalizarlo cuando todo el interfaz sea en qt/tk:
#        self.destroy()
        pass
        #######################################################################

    def mostrar(self):
        """Método creado por compatibilidad con qt, en tkinter no es necesario.
        """
        pass

    def muestrasinesperar(self):
        ''' Muestra el widget sin esperar a regenerar la ventana completa.
        '''
        self.update_idletasks()

    def terminar(self):
        """Destruye la ventana de diálogo.
        """
        self.destroy()


class Botonttk(ttk.Button):

    def __init__(self, *args, **kwargs):
        ttk.Button.__init__(self, *args, **kwargs)


######################################################################################
# La clase Boton recoge todo el contenido de las clases ttk.Button de ttk y Comun
# Para ahorrar código, se incluyen aquí las tareas de colocar el tip y mostrar el widget.
######################################################################################
class Boton(Botonttk, Comun):
    ''' Crea un botón que se puede pulsar.
    '''

    def __init__(self, marco, text, width, height, side, command=None, tip=None, bg=None, fg=None, estilo=None, fuente=None, relief=None, borderwidth=None, padx=None, pady=None, sinmargen=None):
        from .W_main import c

        padx, pady = padx_pady(padx, pady, sinmargen)
        if fuente[2] > 74:
            f3 = 'bold'
        else:
            f3 = 'normal'
        if fuente[3]:
            f4 = 'italic'
        else:
            f4 = 'roman'
        if fuente[4]:
            f5 = 1
        else:
            f5 = 0
        font = tkFont.Font(family=fuente[0], size=fuente[1], weight=f3, slant=f4, underline=f5)
        self.font = font

        s = ttk.Style()
        s.theme_use('alt')

        self.frame = Frame(marco, width=width + 2 * padx, height=height + 2 * pady, padx=padx, pady=pady)
        self.frame.pack_propagate(0)
        self.frame.pack(side=side)

        s.configure(estilo, background=bg, fg= fg, font=font)
        s.map(estilo, background=[('active', bg)])
        if relief:
            s.configure(estilo, relief=relief)

        Botonttk.__init__(self, self.frame, text=text, command=command, style=estilo)

        self._aspecto(tip=tip)
        self.muestra(side=side, fill='both', expand=1)

    def destruye(self):
        ''' Destruye el widget.
        '''
        self.frame.destroy()


def padx_pady(padx=None, pady=None, sinmargen=None):
    ''' Para evitar error cuando no se definen padx y pady.
    '''

    if not padx and not pady:
        padx, pady = 0, 0

    return padx, pady


class InformeLibro(object):
    """Genera y configura la ventana de diálogo y sus componentes.
    :param padre: Ventana que crea este objeto.
    :type padre: Tk
    """
    def __init__(self, titulo, icono, texto, lista, padre=None, portada=None, img_jpg=None):
        from .W_main import Intercambio

        #Definición de la ventana emergente
        self.r = Emergente(padre, '900x500', titulo, icono)
        self.r.resizable(width=False, height=False)

        fListado = Cuadro(self.r, side='top', fill='both', salto=True, borderwidth= 2, relieve='groove', padx=0, pady=0)
        informe = Texto(fListado, width=450, height= 500, side='right', expand='yes', fill='y', relief='groove', borderwidth=2)
        Etiqueta1(fListado, image=portada, width=333, height=500, side='left', expand='yes', fill='y', bg='white', fg='black', alineatexto='center')

        idx = int(texto['EPL_ID: '])
        self.r.bind('<Key-Down>', lambda _idx: self.abajo(idx))
        self.r.bind('<Key-Up>', lambda _idx: self.arriba(idx))

        informe.configure(spacing1=3, background='#F8F4F3')
        fila = 0
        fuente = tkFont.Font(family='Tahoma', size=10, weight='bold')
        informe.tag_config('Datos_libro', foreground='red', font=fuente)
        informe.tag_config('Datos_ePL', foreground='blue', font=fuente)
        informe.tag_config('Sinopsis', foreground='green', font=fuente)
        for info in lista:
            fila += 1
            if info == 'Título: ' or info == 'Autor: ' or info == 'Género: ' or info == 'Colección: ' or\
                                     info == 'Volumen: ' or info == 'Fecha de publicación: ' or\
                                     info == 'Nº de páginas: ' or info == 'Idioma: ': 
                informe.insert(str(fila) + '.0', info)    
                informe.tag_add('Datos_libro', str(fila) + '.0', str(fila) + '.' + str(len(info)))
                informe.insert('end', texto[info] + '\n')
            elif info == 'Sinopsis: ':
                informe.insert(str(fila) + '.0', '\n')
                fila += 1
                informe.insert(str(fila) + '.0', info)    
                informe.tag_add('Sinopsis', str(fila) + '.0', str(fila) + '.' + str(len(info)))
                informe.insert('end', texto[info] + '\n')
                fila += 1
                informe.insert(str(fila) + '.0', '\n')
            elif info == 'EPL_ID: ' or info == 'Revisión: ' or info == 'Publicado en la web: ' or info == 'Estado: ' or\
                                       info == 'Valoración: ' or info == 'Nº de votos: ' or info == 'Portada: ': 
                informe.insert(str(fila) + '.0', info)    
                informe.tag_add('Datos_ePL', str(fila) + '.0', str(fila) + '.' + str(len(info)))
                informe.insert('end', texto[info] + '\n')

        informe.desactiva()

    def abajo(self, idx):
        from .W_main import Intercambio

        idx_next = Intercambio.tv.next(idx)
        if idx_next != '':
            self.r.terminar()
            Intercambio.app.informeLibro(idx_next)
            Intercambio.tv.selection_set(idx_next)

    def arriba(self, idx):
        from .W_main import Intercambio

        idx_prev = Intercambio.tv.prev(idx)
        if idx_prev != '':
            self.r.terminar()
            Intercambio.app.informeLibro(idx_prev)
            Intercambio.tv.selection_set(idx_prev)


def mensajeBox(titulo, texto, botones):
    ''' Crea un widget QMessageBox donde se puede escribir un mensaje.
    '''

    if botones == 'ok':
        messagebox.showinfo(title=titulo, message=texto)
    elif botones == 'sino':
        return askyesno(titulo, texto)
