#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

try:
    # Python3
    from .deTk import *
    try:
        from PIL import Image, ImageTk
    except ImportError:
        try:
        	print('Tu sistema no tiene PIL.\nIMPOSIBLE CONTINUAR.')
        	input('Presione ENTER para salir del programa.')
        except SyntaxError:
        	pass
        sys.exit()
except ImportError:
    try:
        print('Tu sistema no tiene tkinter.\nIMPOSIBLE CONTINUAR.')
        input('Presione ENTER para salir del programa.')
    except SyntaxError:
        pass
    sys.exit()
