#!/usr/bin/python
# -*- coding: utf-8 -*-


import os
import zipfile
from io import BytesIO
from interfaz.widgets import *
from interfaz.W_main import Intercambio, iswindows, islinux, isosx, log
from urllib.request import urlopen


url = 'https://www.dropbox.com/s/a9r4p7oyaftaz1b/csv_full_imgs.zip?dl=1'


def cargarLibros():
    aportes = []
    try:
        resp = urlopen(url, timeout=10)
    except:
        resp = None

    if resp:
        data = resp.read()
        myzipfile = zipfile.ZipFile(BytesIO(data))
        if os.path.isfile(os.path.join(Intercambio.libros, 'datos_csv.txt')):
            bytes_csv = open(os.path.join(Intercambio.libros, 'datos_csv.txt'), 'r')
        else:
            with open(os.path.join(Intercambio.libros, 'datos_csv.txt'), 'w') as Datos_csv:
                Datos_csv.write('0')
                Datos_csv.close()
                bytes_csv = open(os.path.join(Intercambio.libros, 'datos_csv.txt'), 'r')

        len_csv = bytes_csv.readline()
        if int(len_csv) != len(data):
            log('Guardando el CSV en el disco del ordenador.', False)
            with open(os.path.join(Intercambio.libros, 'datos_csv.txt'), 'w') as Datos_csv:
                Datos_csv.write(str(len(data)))
                Datos_csv.close()
            myzipfile.extractall()

    if os.path.isfile(os.path.join(Intercambio.libros, 'csv_full_imgs.csv')):
        log('Leyendo el CSV en el disco del ordenador.', False)
        f = open(os.path.join(Intercambio.libros, 'csv_full_imgs.csv'), 'rb')
    else:
        log('No hay fuente de datos.\nEl programa no puede continuar.', False)
        return aportes

    aportes = f.readlines()

    new_aportes = []
    for lista in aportes:
        lista = (lista.decode('utf-8')).split('","')
        new_aportes.append(lista)
    aportes = new_aportes[:]

    return aportes


def listaColumnas():
    columnas = dict()
    columnas = {'1': ['titulo', 1],
                '2': ['autor', 2],
                '3': ['generos', 3],
                '4': ['coleccion', 4],
                '5': ['volumen', 5],
                '6': ['fecha_publi', 6],
                '7': ['paginas', 8],
                '8': ['revision', 9],
                '9': ['idioma', 10],
                '10': ['publicado', 11],
                '11': ['estado', 12],
                '12': ['valoracion', 13],
                '13': ['votos', 14]}

    return columnas


def verTabla(parent):
    treeview = ttk.Treeview(parent)
    treeview['columns'] = ('titulo', 'autor', 'generos', 'coleccion', 'volumen', 'fecha_publi',\
                           'paginas', 'revision', 'idioma', 'publicado', 'estado', 'valoracion', 'votos')

    ancho_base = treeview.winfo_screenwidth() * 0.90
    ancho0 = int(ancho_base * 0.04)
    ancho1 = int(ancho_base * 0.06)
    ancho2 = int(ancho_base * 0.08)
    ancho3 = int(ancho_base * 0.15)
    ancho4 = int(ancho_base * 0.25)

    treeview.column('#0', width=ancho0, minwidth=ancho0, anchor='e', stretch=True)
    treeview.column('titulo', width=ancho4, anchor='w', stretch=True)
    treeview.column('autor', width=ancho3, anchor='w', stretch=True)
    treeview.column('generos', width=ancho3, anchor='w', stretch=True)
    treeview.column('coleccion', width=ancho3, anchor='w', stretch=True)
    treeview.column('volumen', width=ancho1, anchor='e', stretch=True)
    treeview.column('fecha_publi', width=ancho2, anchor='center', stretch=True)
    treeview.column('paginas', width=ancho0, anchor='e', stretch=True)
    treeview.column('revision', width=ancho0, anchor='center', stretch=True)
    treeview.column('idioma', width=ancho2, anchor='center', stretch=True)
    treeview.column('publicado', width=ancho2, anchor='center', stretch=True)
    treeview.column('estado', width=ancho2, anchor='center', stretch=True)
    treeview.column('valoracion', width=ancho0, anchor='e', stretch=True)
    treeview.column('votos', width=ancho0, anchor='e', stretch=True)

    treeview.heading('#0', text='EPL_ID', anchor='center')
    treeview.heading('titulo', text='Título', anchor='center')
    treeview.heading('autor', text='Autor', anchor='center')
    treeview.heading('generos', text='Géneros', anchor='center')
    treeview.heading('coleccion', text='Colección', anchor='center')
    treeview.heading('volumen', text='Volumen', anchor='center')
    treeview.heading('fecha_publi', text='Publicación', anchor='center')
    treeview.heading('paginas', text='Páginas', anchor='center')
    treeview.heading('revision', text='Revisión', anchor='center')
    treeview.heading('idioma', text='Idioma', anchor='center')
    treeview.heading('publicado', text='Publicado', anchor='center')
    treeview.heading('estado', text='Estado', anchor='center')
    treeview.heading('valoracion', text='Valoración', anchor='center')
    treeview.heading('votos', text='Votos', anchor='center')

    columnas = listaColumnas()
    columnas_visibles = Intercambio.Configura.split('-')
    lista = []
    ancho = int(ancho_base * 0.04)
    for col in columnas_visibles:
        lista.append(columnas[col][0])
        ancho += treeview.column(columnas[col][0], option='width')

    #Adaptar el ancho de las columnas al ancho de la pantalla
    factor = ancho_base / ancho
    for col in lista:
        ancho = treeview.column(col, option='width')
        treeview.column(col, width=int(ancho*factor))

    treeview.configure(displaycolumns=tuple(lista))

    treeview.bind('<Button-1>', lambda event: columnasOrdenar(event, treeview, False, lista))

    if isosx:
        treeview.bind('<Button-2>', lambda event: columnasOrdenar(event, treeview, True, lista))
    else:
        treeview.bind('<Button-3>', lambda event: columnasOrdenar(event, treeview, True, lista))

    return treeview


def columnasOrdenar(evento, tv, sentido=None, lista_display=None):
    if evento.widget == Intercambio.app.bOrdenar:
        treeview_sort_column()
    else:
        #Lista de columnas seleccionadas y orden ascendente o descendente
        if tv.identify_region(evento.x, evento.y) == "heading":
            col = tv.identify_column(evento.x)
            nom_col = lista_display[int(col.lstrip('#'))-1]

            cadena = tv.heading(nom_col, option='text')
            if (nom_col, False) in Intercambio.lista_ordenar:
                pos = cadena.find('▲')
                cadena = cadena[0:pos]
                tv.heading(nom_col, text=str(cadena))
                Intercambio.lista_ordenar.remove((nom_col, False))
            elif (nom_col, True) in Intercambio.lista_ordenar:
                pos = cadena.find('▼')
                cadena = cadena[0:pos]
                tv.heading(nom_col, text=str(cadena))
                Intercambio.lista_ordenar.remove((nom_col, True))
            else:
                Intercambio.lista_ordenar.append((nom_col, sentido))
                if sentido:
                    tv.heading(nom_col, text=str(cadena) + '▼')
                else:
                    tv.heading(nom_col, text=str(cadena) + '▲')


def treeview_sort_column():
    Intercambio.lista_ordenar = Intercambio.lista_ordenar[::-1]

    col_orden = dict()
    col_orden = {'titulo' : 1,
                 'autor' : 2,
                 'generos' : 3,
                 'coleccion' : 4,
                 'volumen' : 5,
                 'fecha_publi' : 6,
                 'paginas' : 7,
                 'revision' : 8,
                 'idioma' : 9,
                 'publicado' : 10,
                 'estado' : 11,
                 'valoracion' : 12,
                 'votos' : 13
                 }

    intab ='áàāéèēíìīóòöōúùüūÁÀÅÉÈÍÌÓÒÖŌÚÙÜ' 
    outtab = 'aaaeeeiiioooouuuuAAAEEIIOOOOUUU'
    trantab = str.maketrans(intab, outtab)

    for nom_col, sentido in Intercambio.lista_ordenar:
        orden = col_orden[nom_col]
        if nom_col == 'publicado':
            #lista = x[orden].split(':')
            #fecha = lista[1].split('-')
            #fecha = ''.join(lista[1].split('-')[::-1])
            #cadena_fecha = str(''.join(fecha) + x[orden].split(':')[0]
            Intercambio.lista_tuplas_insertadas.sort(reverse=sentido, key=lambda x: str(''.join(x[orden].split(':')[1].split('-')[::-1])) + x[orden].split(':')[0])
        elif nom_col == 'volumen' or nom_col == 'revision' or nom_col == 'valoracion':
            Intercambio.lista_tuplas_insertadas.sort(reverse=sentido, key=lambda x: float(x[orden]) if x[orden] != '' else float(0))
        elif nom_col == 'fecha_publi' or nom_col == 'paginas' or nom_col == 'votos':
            Intercambio.lista_tuplas_insertadas.sort(reverse=sentido, key=lambda x: int(x[orden]) if x[orden] != '' else int(0))
        else:
            Intercambio.lista_tuplas_insertadas.sort(reverse=sentido, key=lambda x: (str(x[orden]).translate(trantab)).capitalize() if x[orden] != 'str' else str(''))

    listarOrdenados(Intercambio.lista_tuplas_insertadas)


def listarFiltrados(parent, ventana, entradas, aportes, filtro, treeview):
    tipo_fecha = ''
    control = 0
    lista = []
    insertados = {}
    Intercambio.lista_tuplas_insertadas = []
    progress = 0
    textFiltro = ''
    textFiltro += 'Título: ' + str(filtro[0])
    textFiltro += ' - Autor: ' + str(filtro[1])
    textFiltro += ' - Género: ' + str(filtro[2])
    textFiltro += ' - Colección: ' + str(filtro[3])
    textFiltro += ' - Idioma: ' + str(filtro[4])
    textFiltro += ' - Fecha inicial: ' + str(filtro[5])
    textFiltro += ' - Fecha final: ' + str(filtro[6])
    new_filtro, tipo_fecha = tipoFecha(filtro)
    del(aportes[0])
    for lista in aportes:
        progress += 1
        lista_values = []
        lista_values = lista[:]
        #Eliminar los elementos 0, 7 y 16 de lista_values 
        index = [0, 7, 16]
        tupla_values = tuple([i for i in lista_values if lista_values.index(i) not in index])
        if filtrar(lista, new_filtro, tipo_fecha):
            control += 1
            clave = ''
            clave = lista[0].lstrip('"')
            treeview.insert('', 'end', iid=clave, text=clave, values=tupla_values)
            insertados[clave] = lista
            tupla_values = tupla_values[:0] + (clave,) + tupla_values[0:]
            Intercambio.lista_tuplas_insertadas.append(tupla_values)

    if len(insertados) != 0:
        ventana.oculta()
        entradas.destroy()
        if iswindows or isosx:
            try:
                parent.state('zoomed')
            except:
                parent.attributes('-fullscreen', True)
        elif islinux:
            parent.attributes('-zoomed', True)

        treeview.pack(side='top', expand='yes', fill='both')
        Intercambio.app.entradasListado()
        Intercambio.app.lLibros.inserta('Se han listado ' + str(control) + ' libros, con el filtro: ' + textFiltro)

        Intercambio.app.bOrdenar.bind('<Button-1>', lambda event: columnasOrdenar(event, treeview))
        Intercambio.tv = treeview
    else:
        log('No existen registros que cumplan con el filtro.', False)
        treeview.destroy()

    return insertados


def listarOrdenados(ordenados):
    Intercambio.tv.destroy()
    tv_new = verTabla(Intercambio.raiz)
    for values in ordenados:
        clave = ''
        clave = values[0]
        values = list(values)
        values.pop(0)
        values = tuple(values)
        tv_new.insert('', 'end', iid=clave, text=clave, values=values)

    tv_new.pack(side='top', expand='yes', fill='both')
    Intercambio.tv = tv_new
    Intercambio.lista_ordenar = []


def filtrar(lista, filtro, tipo_fecha):
    if filtro[0] == '' and filtro[1] == '' and filtro[2] == '' and filtro[3] == '' and filtro[4] == '' and filtro[5] == '' and filtro[6] == '':     
        return True

    if filtro[0] == '' or contiene(filtro[0], lista[1]):
        pass
    else:
        return False

    if filtro[1] == '' or contiene(filtro[1], lista[2]):
        pass
    else:
        return False

    if filtro[2] == '' or contiene(filtro[2], lista[3]):
        pass
    else:
        return False

    if filtro[3] == '' or contiene(filtro[3], lista[4]):
        pass
    else:
        return False

    if filtro[4] == '' or contiene(filtro[4], lista[10]):
        pass
    else:
        return False

    if (filtro[5] == '' and filtro[6] == '') or compararFechas(filtro[5], filtro[6], lista[11], tipo_fecha):
        pass
    else:
        return False

    return True


def contiene(filtro, valor):
    filtro = filtro.split(',')
    valor = valor.lower()
    valor = quitarAcentos(valor)

    for algo in filtro:
        algo = algo.lower()
        algo = quitarAcentos(algo)
        if valor.find(algo) != -1:
            return True
    return False


def quitarAcentos(cadena):
    import unicodedata

    nfkd_form = unicodedata.normalize('NFKD', cadena)
    return u"".join([c for c in nfkd_form if not unicodedata.combining(c)])


def tipoFecha(filtro):
    if filtro[5] == filtro[6] == '':
        filtro[5] = '01-01-2010'
        filtro[6] = '31-12-2030'
        return filtro, ''
    elif filtro[5].find('P:') == filtro[6].find('P:') == 0:
        return filtro, 'P:'
    elif filtro[5].find('A:') == filtro[6].find('A:') == 0:
        return filtro, 'A:'
    elif filtro[5].find('P:') == 0 and filtro[6] == '':
        filtro[6] = 'P:31-12-2030'
        return filtro, 'P:'
    elif filtro[5].find('A:') == 0 and filtro[6] == '':
        filtro[6] = 'A:31-12-2030'
        return filtro, 'A:'
    elif filtro[5] == '' and filtro[6].find('P:') == 0:
        filtro[5] = 'P:01-01-2010'
        return filtro, 'P:'
    elif filtro[5] == '' and filtro[6].find('A:') == 0:
        filtro[5] = 'A:01-01-2010'
        return filtro, 'A:'
    elif filtro[5] != '' and filtro[6] == '':
        filtro[6] = '31-12-2030'
        return filtro, ''
    elif filtro[5] == '' and filtro[6] != '':
        filtro[5] = '01-01-2010'
        return filtro, ''
    elif filtro[5] != '' and filtro[6] != '':
        return filtro, ''


def limpiarFecha(fecha):
    if fecha.find('P:') == 0:
        return fecha.lstrip('P:')
    elif fecha.find('A:') == 0:
        return fecha.lstrip('A:')
    else:
        return fecha


def compararFechas(filtro1, filtro2, valor, tipo_fecha):
    if tipo_fecha == 'P:' or tipo_fecha == 'A:':
        if valor.find(tipo_fecha) == 0:
            fechaIni = (limpiarFecha(filtro1)).split('-')
            fechaIni = ''.join(fechaIni[::-1])
            fechaFin = (limpiarFecha(filtro2)).split('-')
            fechaFin = ''.join(fechaFin[::-1])
            valor = (limpiarFecha(valor)).split('-')
            valor = ''.join(valor[::-1])
            if valor >= fechaIni and valor <= fechaFin:
                return True
            else:
                return False
        else:
            return False
    else:
        fechaIni = filtro1.split('-')
        fechaIni = ''.join(fechaIni[::-1])
        fechaFin = filtro2.split('-')
        fechaFin = ''.join(fechaFin[::-1])
        valor = (limpiarFecha(valor)).split('-')
        valor = ''.join(valor[::-1])
        if valor >= fechaIni and valor <= fechaFin:
            return True
        else:
            return False
